#ifndef SYSCALLS_H
#define SYSCALLS_H

void print_int(int);
void print_string(char *);
void print_char(char c);

int read_int();
void read_string();
char read_char();

#endif